create database skojic_19 default character set utf8;
use skojic_19;
create table ontologija(
    sifra int not null primary key auto_increment,
    nazivKnjige varchar(255) not null,
    autor varchar(255) not null,
    zanr varchar(255) not null,
    biljeska varchar(255) not null
);
insert into ontologija(nazivKnjige, autor, zanr, biljeska) 
values ("Test", "Test", "Test", "Test");
