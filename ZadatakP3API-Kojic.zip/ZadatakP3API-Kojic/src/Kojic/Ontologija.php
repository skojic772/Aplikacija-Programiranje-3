<?php

namespace Kojic;

/**
 * @Entity @Table(name="ontologija")
 **/


class Ontologija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $nazivKnjige;

     /**
    * @Column(type="string")
    */
    private $autor;


    /**
    * @Column(type="string")
    */
    private $zanr;

    /**
    * @Column(type="string")
    */
    private $biljeska;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getNazivKnjige(){
      return $this->nazivKnjige;
    }
  
    public function setNazivKnjige($nazivKnjige){
      $this->nazivKnjige = $nazivKnjige;
    }
  
    public function getAutor(){
      return $this->autor;
    }
  
    public function setAutor($autor){
      $this->autor = $autor;
    }
  
    public function getZanr(){
      return $this->zanr;
    }
  
    public function setZanr($zanr){
      $this->zanr = $zanr;
    }
  
    public function getBiljeska(){
      return $this->biljeska;
    }
  
    public function setBiljeska($biljeska){
      $this->biljeska = $biljeska;
    }
    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
