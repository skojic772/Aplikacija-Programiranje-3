<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Kojic\Ontologija;
use Kojic\Projekt;
use Composer\Autoload\ClassLoader;

Flight::route('/', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/skojic_19/skojic_19.rdf');
  $info = $foaf->dump();
  echo "<h2>Ontologija za P3 zadatak:</h2> <br/><br/>" . $info;
});

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Kojic\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /fill', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('https://oziz.ffos.hr/nastava20192020/skojic_19/skojic_19.rdf');
  foreach ($foaf->resources() as $resource) {

    $name = $foaf->get($resource, 'foaf:name');

    $autor = $foaf->get($resource, 'dc:title'); 

    if($name != ''){

      $i = 0;
      $annotations = "";

      
      $description = $foaf->get($resource, 'dc:description'); 

      foreach ($resource->properties() as $key) {
          $annotations .= $key . ': ' . $foaf->get($resource, $key) . "\n"; 
      }

      $ontologija = new Ontologija();
      $ontologija->setPodaci(Flight::request()->data);


      $ontologija->setNazivKnjige($name); 
      $ontologija->setAutor($autor); 
      $ontologija->setZanr($description);
      $ontologija->setBiljeska($annotations);

      $doctrineBootstrap = Flight::entityManager();
      $em = $doctrineBootstrap->getEntityManager();

      $em->persist($ontologija);
      $em->flush();

    
    }
  }

  echo "U bazu je uspješno unijeta ontologija.";

});

Flight::route('GET /search/@name', function($name){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Kojic\Ontologija');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.nazivKnjige LIKE :nazivKnjige')
                        ->setParameter('nazivKnjige', '%'.$name.'%')
                        ->getQuery()
                        ->getResult();  
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Kojic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();

